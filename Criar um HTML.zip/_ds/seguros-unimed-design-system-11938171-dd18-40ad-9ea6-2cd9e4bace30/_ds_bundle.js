/* @ds-bundle: {"format":3,"namespace":"SegurosUnimedDesignSystem_119381","components":[{"name":"Button","sourcePath":"components/actions/Button.jsx"},{"name":"IconButton","sourcePath":"components/actions/IconButton.jsx"},{"name":"Icon","sourcePath":"components/brand/Icon.jsx"},{"name":"Logo","sourcePath":"components/brand/Logo.jsx"},{"name":"Avatar","sourcePath":"components/data-display/Avatar.jsx"},{"name":"Badge","sourcePath":"components/data-display/Badge.jsx"},{"name":"Card","sourcePath":"components/data-display/Card.jsx"},{"name":"Tag","sourcePath":"components/data-display/Tag.jsx"},{"name":"Alert","sourcePath":"components/feedback/Alert.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Radio","sourcePath":"components/forms/Radio.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"}],"sourceHashes":{"components/actions/Button.jsx":"256df1ea8691","components/actions/IconButton.jsx":"2349f94d7f30","components/brand/Icon.jsx":"25f8bfb91ca7","components/brand/Logo.jsx":"010e7db3a16d","components/data-display/Avatar.jsx":"13af9822a74b","components/data-display/Badge.jsx":"0979a1dca720","components/data-display/Card.jsx":"9d6afcc4a29e","components/data-display/Tag.jsx":"9856c8d5ba13","components/feedback/Alert.jsx":"04ebf70c37f0","components/forms/Checkbox.jsx":"637575af1cd3","components/forms/Input.jsx":"db3252b32924","components/forms/Radio.jsx":"1f539bf2a726","components/forms/Select.jsx":"821fe34e006c","components/forms/Switch.jsx":"1d95795c85ea","components/navigation/Tabs.jsx":"e17cc9a58687","ui_kits/portal/AppShell.jsx":"4c1d0ad2a962","ui_kits/portal/DashboardScreen.jsx":"9315022161cb","ui_kits/portal/LoginScreen.jsx":"3a36c282d276","ui_kits/portal/ProductDetailScreen.jsx":"b2eda72e983d","ui_kits/portal/data.js":"28733910783e"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.SegurosUnimedDesignSystem_119381 = window.SegurosUnimedDesignSystem_119381 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/brand/Icon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Brand icon — thin wrapper over Lucide (the substitute for the licensed
 * Unimed icon set). Requires the Lucide UMD script on the page:
 *   <script src="https://unpkg.com/lucide@latest"></script>
 * Renders monochrome line icons that inherit `color` (currentColor).
 */
function Icon({
  name,
  size = 20,
  strokeWidth = 1.75,
  color,
  style,
  className,
  ...rest
}) {
  const ref = React.useRef(null);
  React.useEffect(() => {
    const host = ref.current;
    if (!host || !window.lucide) return;
    host.innerHTML = '';
    const i = document.createElement('i');
    i.setAttribute('data-lucide', name);
    host.appendChild(i);
    try {
      window.lucide.createIcons({
        icons: window.lucide.icons,
        nameAttr: 'data-lucide'
      });
    } catch (e) {/* lucide not ready */}
    const svg = host.querySelector('svg');
    if (svg) {
      svg.setAttribute('width', size);
      svg.setAttribute('height', size);
      svg.setAttribute('stroke-width', strokeWidth);
    }
  }, [name, size, strokeWidth]);
  return /*#__PURE__*/React.createElement("span", _extends({
    ref: ref,
    className: className,
    "aria-hidden": "true",
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: size,
      height: size,
      color: color || 'currentColor',
      flex: '0 0 auto',
      ...style
    }
  }, rest));
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/Icon.jsx", error: String((e && e.message) || e) }); }

// components/actions/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const SIZES = {
  sm: {
    height: 40,
    padW: 20,
    font: 14,
    gap: 6,
    icon: 16
  },
  md: {
    height: 48,
    padW: 28,
    font: 16,
    gap: 8,
    icon: 18
  },
  lg: {
    height: 64,
    padW: 40,
    font: 16,
    gap: 8,
    icon: 20
  }
};
function visuals(variant) {
  switch (variant) {
    case 'secondary':
      return {
        background: 'var(--action-secondary-bg)',
        color: 'var(--action-secondary-label)',
        border: '1px solid var(--action-secondary-border)',
        hoverBorder: 'var(--action-secondary-border-hover)'
      };
    case 'success':
      return {
        background: 'var(--action-success-bg)',
        color: 'var(--text-on-brand)',
        border: '1px solid transparent',
        hoverBg: 'var(--action-success-bg-hover)'
      };
    case 'ghost':
      return {
        background: 'transparent',
        color: 'var(--action-secondary-label)',
        border: '1px solid transparent',
        hoverBg: 'var(--colors-blue-0)'
      };
    case 'danger':
      return {
        background: 'var(--colors-red-500)',
        color: 'var(--text-on-brand)',
        border: '1px solid transparent',
        hoverBg: 'var(--colors-red-700)'
      };
    default:
      // primary
      return {
        background: 'var(--action-primary-bg)',
        color: 'var(--action-primary-label)',
        border: '1px solid transparent',
        hoverBg: 'var(--action-primary-bg-hover)'
      };
  }
}

/**
 * Primary action button. Navy solid by default; secondary outline,
 * green success, ghost and danger variants. SM / MD / LG sizes.
 */
function Button({
  children,
  variant = 'primary',
  size = 'lg',
  block = false,
  loading = false,
  disabled = false,
  iconLeft,
  iconRight,
  type = 'button',
  style,
  className,
  ...rest
}) {
  const s = SIZES[size] || SIZES.lg;
  const v = visuals(variant);
  const [hover, setHover] = React.useState(false);
  const isDisabled = disabled || loading;
  const base = {
    display: block ? 'flex' : 'inline-flex',
    width: block ? '100%' : undefined,
    alignItems: 'center',
    justifyContent: 'center',
    gap: s.gap,
    height: s.height,
    padding: `0 ${s.padW}px`,
    borderRadius: 'var(--radius-sm)',
    fontFamily: 'var(--font-sans)',
    fontSize: s.font,
    fontWeight: 'var(--weight-semibold)',
    lineHeight: 1,
    cursor: isDisabled ? 'not-allowed' : 'pointer',
    transition: 'background-color .15s ease, border-color .15s ease, color .15s ease',
    background: v.background,
    color: v.color,
    border: v.border,
    boxSizing: 'border-box',
    whiteSpace: 'nowrap'
  };
  if (isDisabled) {
    base.background = variant === 'secondary' || variant === 'ghost' ? 'var(--action-secondary-bg)' : 'var(--action-disabled-bg)';
    base.color = 'var(--action-disabled-label)';
    base.border = variant === 'secondary' ? '1px solid var(--action-secondary-border)' : '1px solid transparent';
  } else if (hover) {
    if (v.hoverBg) base.background = v.hoverBg;
    if (v.hoverBorder) base.borderColor = v.hoverBorder;
  }
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    disabled: isDisabled,
    className: className,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      ...base,
      ...style
    }
  }, rest), loading ? /*#__PURE__*/React.createElement(Spinner, {
    color: base.color
  }) : /*#__PURE__*/React.createElement(React.Fragment, null, iconLeft && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconLeft,
    size: s.icon
  }), children, iconRight && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconRight,
    size: s.icon
  })));
}
function Spinner({
  color
}) {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      width: 18,
      height: 18,
      borderRadius: '50%',
      border: '2px solid currentColor',
      borderRightColor: 'transparent',
      opacity: 0.9,
      color,
      display: 'inline-block',
      animation: 'su-spin .7s linear infinite'
    }
  }, /*#__PURE__*/React.createElement("style", null, `@keyframes su-spin{to{transform:rotate(360deg)}}`));
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/actions/Button.jsx", error: String((e && e.message) || e) }); }

// components/actions/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const SIZES = {
  sm: 40,
  md: 48,
  lg: 64
};
const ICON = {
  sm: 18,
  md: 20,
  lg: 24
};

/**
 * Square icon-only button. Same variants as Button.
 */
function IconButton({
  icon,
  variant = 'secondary',
  size = 'md',
  disabled = false,
  shape = 'rounded',
  'aria-label': ariaLabel,
  style,
  className,
  ...rest
}) {
  const dim = SIZES[size] || SIZES.md;
  const [hover, setHover] = React.useState(false);
  let bg = 'transparent',
    color = 'var(--colors-blue-800)',
    border = '1px solid transparent';
  if (variant === 'secondary') {
    bg = 'var(--action-secondary-bg)';
    border = '1px solid var(--action-secondary-border)';
  }
  if (variant === 'primary') {
    bg = 'var(--action-primary-bg)';
    color = 'var(--action-primary-label)';
  }
  if (variant === 'success') {
    bg = 'var(--action-success-bg)';
    color = 'var(--text-on-brand)';
  }
  if (disabled) {
    bg = variant === 'ghost' ? 'transparent' : 'var(--action-disabled-bg)';
    color = 'var(--action-disabled-label)';
    border = '1px solid transparent';
  } else if (hover) {
    if (variant === 'primary') bg = 'var(--action-primary-bg-hover)';else if (variant === 'success') bg = 'var(--action-success-bg-hover)';else if (variant === 'secondary') border = '1px solid var(--action-secondary-border-hover)';else bg = 'var(--colors-blue-0)';
  }
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    "aria-label": ariaLabel,
    disabled: disabled,
    className: className,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      width: dim,
      height: dim,
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: bg,
      color,
      border,
      borderRadius: shape === 'circle' ? 'var(--radius-full)' : 'var(--radius-sm)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      transition: 'background-color .15s ease, border-color .15s ease',
      boxSizing: 'border-box',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: ICON[size] || 20
  }));
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/actions/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/brand/Logo.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const LOGOS = {
  box: 'seguros-unimed-box.svg',
  symbol: 'seguros-unimed-symbol.svg',
  white: 'seguros-unimed-white.svg',
  pinheiro: 'pinheiro-navy.svg',
  'pinheiro-green': 'pinheiro-green.svg',
  'pinheiro-white': 'pinheiro-white.svg'
};

/**
 * Seguros Unimed logo lockups. Renders the approved SVG marks — never
 * recreate the wordmark as live text.
 *
 * `base` points at the assets/logos directory relative to the page.
 */
function Logo({
  variant = 'box',
  height = 40,
  base = 'assets/logos',
  alt = 'Seguros Unimed',
  style,
  className,
  ...rest
}) {
  const file = LOGOS[variant] || LOGOS.box;
  return /*#__PURE__*/React.createElement("img", _extends({
    src: `${base}/${file}`,
    alt: alt,
    className: className,
    style: {
      height,
      width: 'auto',
      display: 'block',
      ...style
    }
  }, rest));
}
Object.assign(__ds_scope, { Logo });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/Logo.jsx", error: String((e && e.message) || e) }); }

// components/data-display/Avatar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const SIZES = {
  sm: 32,
  md: 40,
  lg: 56
};
function initials(name = '') {
  return name.trim().split(/\s+/).slice(0, 2).map(p => p[0]).join('').toUpperCase();
}

/** User avatar — image or initials, on a navy tint by default. */
function Avatar({
  name,
  src,
  size = 'md',
  tone = 'brand',
  style,
  className,
  ...rest
}) {
  const dim = SIZES[size] || (typeof size === 'number' ? size : 40);
  const tones = {
    brand: {
      bg: 'var(--colors-blue-0)',
      fg: 'var(--colors-blue-800)'
    },
    green: {
      bg: 'var(--colors-green-50)',
      fg: 'var(--colors-green-700)'
    },
    neutral: {
      bg: 'var(--colors-grey-100)',
      fg: 'var(--colors-grey-700)'
    }
  };
  const t = tones[tone] || tones.brand;
  return /*#__PURE__*/React.createElement("span", _extends({
    className: className,
    style: {
      width: dim,
      height: dim,
      borderRadius: 'var(--radius-full)',
      overflow: 'hidden',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: t.bg,
      color: t.fg,
      fontFamily: 'var(--font-sans)',
      fontWeight: 'var(--weight-semibold)',
      fontSize: dim * 0.4,
      flex: '0 0 auto',
      ...style
    }
  }, rest), src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: name || '',
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover'
    }
  }) : initials(name));
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/data-display/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TONES = {
  neutral: {
    bg: 'var(--colors-grey-100)',
    fg: 'var(--colors-grey-700)'
  },
  brand: {
    bg: 'var(--colors-blue-0)',
    fg: 'var(--colors-blue-800)'
  },
  success: {
    bg: 'var(--colors-green-50)',
    fg: 'var(--colors-green-700)'
  },
  danger: {
    bg: 'var(--colors-red-0)',
    fg: 'var(--colors-red-700)'
  },
  warning: {
    bg: 'var(--colors-orange-0)',
    fg: 'var(--colors-orange-700)'
  },
  info: {
    bg: 'var(--colors-cyan-0)',
    fg: 'var(--colors-cyan-800)'
  }
};

/** Small status/label pill. */
function Badge({
  children,
  tone = 'neutral',
  dot = false,
  style,
  className,
  ...rest
}) {
  const t = TONES[tone] || TONES.neutral;
  return /*#__PURE__*/React.createElement("span", _extends({
    className: className,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      padding: '3px 10px',
      borderRadius: 'var(--radius-full)',
      background: t.bg,
      color: t.fg,
      fontFamily: 'var(--font-sans)',
      fontSize: 12,
      fontWeight: 'var(--weight-semibold)',
      lineHeight: 1.4,
      whiteSpace: 'nowrap',
      ...style
    }
  }, rest), dot && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: '50%',
      background: 'currentColor'
    }
  }), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/Badge.jsx", error: String((e && e.message) || e) }); }

// components/data-display/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Surface container. White, 16px radius, hairline border and/or soft shadow.
 * Set `signature` to use the brand box shape (three round corners + one square).
 */
function Card({
  children,
  elevation = 'sm',
  padding = 24,
  signature = false,
  interactive = false,
  style,
  className,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const shadow = {
    none: 'none',
    xs: 'var(--shadow-xs)',
    sm: 'var(--shadow-sm)',
    md: 'var(--shadow-md)',
    lg: 'var(--shadow-lg)'
  }[elevation] || 'var(--shadow-sm)';
  return /*#__PURE__*/React.createElement("div", _extends({
    className: className,
    onMouseEnter: () => interactive && setHover(true),
    onMouseLeave: () => interactive && setHover(false),
    style: {
      background: 'var(--surface-card)',
      border: '1px solid var(--border-subtle)',
      borderRadius: signature ? 'var(--radius-signature)' : 'var(--radius-md)',
      boxShadow: interactive && hover ? 'var(--shadow-md)' : shadow,
      padding,
      transition: 'box-shadow .18s ease, transform .18s ease',
      transform: interactive && hover ? 'translateY(-2px)' : 'none',
      cursor: interactive ? 'pointer' : 'default',
      boxSizing: 'border-box',
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/Card.jsx", error: String((e && e.message) || e) }); }

// components/data-display/Tag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Removable/selectable chip (e.g. product filters, categories). */
function Tag({
  children,
  icon,
  selected = false,
  onRemove,
  onClick,
  style,
  className,
  ...rest
}) {
  const clickable = !!onClick;
  return /*#__PURE__*/React.createElement("span", _extends({
    className: className,
    onClick: onClick,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      padding: '6px 12px',
      borderRadius: 'var(--radius-full)',
      border: `1px solid ${selected ? 'var(--colors-blue-800)' : 'var(--border-default)'}`,
      background: selected ? 'var(--colors-blue-0)' : 'var(--surface-card)',
      color: selected ? 'var(--colors-blue-800)' : 'var(--text-secondary)',
      fontFamily: 'var(--font-sans)',
      fontSize: 14,
      fontWeight: 'var(--weight-medium)',
      cursor: clickable ? 'pointer' : 'default',
      lineHeight: 1.2,
      whiteSpace: 'nowrap',
      transition: 'border-color .15s ease, background-color .15s ease',
      ...style
    }
  }, rest), icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 15
  }), children, onRemove && /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: e => {
      e.stopPropagation();
      onRemove(e);
    },
    "aria-label": "Remover",
    style: {
      display: 'inline-flex',
      border: 'none',
      background: 'transparent',
      padding: 0,
      margin: 0,
      cursor: 'pointer',
      color: 'inherit'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "x",
    size: 14
  })));
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/Tag.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Alert.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TONES = {
  info: {
    bg: 'var(--colors-cyan-0)',
    fg: 'var(--colors-cyan-800)',
    bd: 'var(--colors-cyan-600)',
    icon: 'info'
  },
  success: {
    bg: 'var(--colors-green-0)',
    fg: 'var(--colors-green-800)',
    bd: 'var(--colors-green-500)',
    icon: 'check-circle'
  },
  warning: {
    bg: 'var(--colors-orange-0)',
    fg: 'var(--colors-orange-700)',
    bd: 'var(--colors-orange-400)',
    icon: 'alert-triangle'
  },
  danger: {
    bg: 'var(--colors-red-0)',
    fg: 'var(--colors-red-700)',
    bd: 'var(--colors-red-500)',
    icon: 'alert-circle'
  }
};

/** Inline message banner. */
function Alert({
  tone = 'info',
  title,
  children,
  onClose,
  style,
  className,
  ...rest
}) {
  const t = TONES[tone] || TONES.info;
  return /*#__PURE__*/React.createElement("div", _extends({
    className: className,
    role: "status",
    style: {
      display: 'flex',
      gap: 12,
      padding: '14px 16px',
      borderRadius: 'var(--radius-md)',
      background: t.bg,
      color: t.fg,
      border: `1px solid ${t.bd}33`,
      fontFamily: 'var(--font-sans)',
      boxSizing: 'border-box',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      color: t.bd,
      display: 'inline-flex',
      flex: '0 0 auto',
      marginTop: 1
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: t.icon,
    size: 20
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, title && /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 'var(--weight-semibold)',
      fontSize: 15,
      marginBottom: children ? 2 : 0
    }
  }, title), children && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      lineHeight: 1.5,
      color: 'var(--text-secondary)'
    }
  }, children)), onClose && /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onClose,
    "aria-label": "Fechar",
    style: {
      border: 'none',
      background: 'transparent',
      cursor: 'pointer',
      color: 'inherit',
      padding: 0,
      display: 'inline-flex',
      flex: '0 0 auto'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "x",
    size: 18
  })));
}
Object.assign(__ds_scope, { Alert });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Alert.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Checkbox with label. Controlled via `checked`/`onChange` or uncontrolled. */
function Checkbox({
  label,
  checked,
  defaultChecked,
  disabled = false,
  onChange,
  style,
  className,
  ...rest
}) {
  const isControlled = checked !== undefined;
  const [internal, setInternal] = React.useState(!!defaultChecked);
  const on = isControlled ? checked : internal;
  function toggle(e) {
    if (disabled) return;
    if (!isControlled) setInternal(e.target.checked);
    onChange && onChange(e);
  }
  return /*#__PURE__*/React.createElement("label", {
    className: className,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 10,
      fontFamily: 'var(--font-sans)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      ...style
    }
  }, /*#__PURE__*/React.createElement("input", _extends({
    type: "checkbox",
    checked: isControlled ? checked : undefined,
    defaultChecked: isControlled ? undefined : defaultChecked,
    disabled: disabled,
    onChange: toggle,
    style: {
      position: 'absolute',
      opacity: 0,
      width: 0,
      height: 0
    }
  }, rest)), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 20,
      height: 20,
      flex: '0 0 auto',
      borderRadius: 'var(--radius-xs)',
      border: `1px solid ${on ? 'var(--colors-blue-800)' : 'var(--border-strong)'}`,
      background: on ? 'var(--colors-blue-800)' : disabled ? 'var(--colors-grey-50)' : 'var(--surface-card)',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: '#fff',
      transition: 'background-color .15s ease, border-color .15s ease'
    }
  }, on && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "check",
    size: 14,
    strokeWidth: 3
  })), label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 15,
      color: disabled ? 'var(--text-disabled)' : 'var(--text-primary)'
    }
  }, label));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Text input with label, helper text and error state.
 */
function Input({
  label,
  helper,
  error,
  iconLeft,
  iconRight,
  disabled = false,
  id,
  style,
  className,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const autoId = React.useId();
  const inputId = id || autoId;
  let borderColor = 'var(--border-default)';
  if (error) borderColor = 'var(--colors-red-500)';else if (focus) borderColor = 'var(--colors-blue-800)';
  return /*#__PURE__*/React.createElement("div", {
    className: className,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6,
      fontFamily: 'var(--font-sans)',
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: inputId,
    style: {
      fontSize: 14,
      fontWeight: 'var(--weight-semibold)',
      color: 'var(--text-primary)'
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      height: 48,
      padding: '0 14px',
      borderRadius: 'var(--radius-sm)',
      border: `1px solid ${borderColor}`,
      background: disabled ? 'var(--colors-grey-50)' : 'var(--surface-card)',
      boxShadow: focus && !error ? 'var(--focus-ring)' : 'none',
      transition: 'border-color .15s ease, box-shadow .15s ease',
      boxSizing: 'border-box'
    }
  }, iconLeft && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconLeft,
    size: 18,
    color: "var(--text-tertiary)"
  }), /*#__PURE__*/React.createElement("input", _extends({
    id: inputId,
    disabled: disabled,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      flex: 1,
      border: 'none',
      outline: 'none',
      background: 'transparent',
      fontFamily: 'var(--font-sans)',
      fontSize: 16,
      color: 'var(--text-primary)',
      minWidth: 0
    }
  }, rest)), iconRight && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconRight,
    size: 18,
    color: "var(--text-tertiary)"
  })), (helper || error) && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: error ? 'var(--text-danger)' : 'var(--text-tertiary)'
    }
  }, error || helper));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Radio.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Radio button with label. Use a shared `name` to group. */
function Radio({
  label,
  checked,
  defaultChecked,
  disabled = false,
  onChange,
  name,
  value,
  style,
  className,
  ...rest
}) {
  const isControlled = checked !== undefined;
  const on = checked;
  return /*#__PURE__*/React.createElement("label", {
    className: className,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 10,
      fontFamily: 'var(--font-sans)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      ...style
    }
  }, /*#__PURE__*/React.createElement("input", _extends({
    type: "radio",
    name: name,
    value: value,
    checked: isControlled ? checked : undefined,
    defaultChecked: isControlled ? undefined : defaultChecked,
    disabled: disabled,
    onChange: onChange,
    style: {
      position: 'absolute',
      opacity: 0,
      width: 0,
      height: 0
    }
  }, rest)), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 20,
      height: 20,
      flex: '0 0 auto',
      borderRadius: 'var(--radius-full)',
      border: `1px solid ${on ? 'var(--colors-blue-800)' : 'var(--border-strong)'}`,
      background: disabled ? 'var(--colors-grey-50)' : 'var(--surface-card)',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      transition: 'border-color .15s ease'
    }
  }, on && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 10,
      height: 10,
      borderRadius: '50%',
      background: 'var(--colors-blue-800)'
    }
  })), label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 15,
      color: disabled ? 'var(--text-disabled)' : 'var(--text-primary)'
    }
  }, label));
}
Object.assign(__ds_scope, { Radio });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Radio.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Labelled select (native, brand-styled). */
function Select({
  label,
  helper,
  error,
  disabled = false,
  children,
  id,
  style,
  className,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const autoId = React.useId();
  const selId = id || autoId;
  let borderColor = 'var(--border-default)';
  if (error) borderColor = 'var(--colors-red-500)';else if (focus) borderColor = 'var(--colors-blue-800)';
  return /*#__PURE__*/React.createElement("div", {
    className: className,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6,
      fontFamily: 'var(--font-sans)',
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: selId,
    style: {
      fontSize: 14,
      fontWeight: 'var(--weight-semibold)',
      color: 'var(--text-primary)'
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      display: 'flex',
      alignItems: 'center',
      height: 48,
      borderRadius: 'var(--radius-sm)',
      border: `1px solid ${borderColor}`,
      background: disabled ? 'var(--colors-grey-50)' : 'var(--surface-card)',
      boxShadow: focus && !error ? 'var(--focus-ring)' : 'none',
      transition: 'border-color .15s ease, box-shadow .15s ease',
      boxSizing: 'border-box'
    }
  }, /*#__PURE__*/React.createElement("select", _extends({
    id: selId,
    disabled: disabled,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      flex: 1,
      appearance: 'none',
      WebkitAppearance: 'none',
      border: 'none',
      outline: 'none',
      background: 'transparent',
      fontFamily: 'var(--font-sans)',
      fontSize: 16,
      color: 'var(--text-primary)',
      padding: '0 40px 0 14px',
      height: '100%',
      cursor: disabled ? 'not-allowed' : 'pointer'
    }
  }, rest), children), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      right: 12,
      pointerEvents: 'none',
      color: 'var(--text-tertiary)',
      display: 'inline-flex'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevron-down",
    size: 18
  }))), (helper || error) && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: error ? 'var(--text-danger)' : 'var(--text-tertiary)'
    }
  }, error || helper));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Toggle switch. Controlled (`checked`/`onChange`) or uncontrolled. */
function Switch({
  checked,
  defaultChecked,
  disabled = false,
  onChange,
  label,
  style,
  className,
  ...rest
}) {
  const isControlled = checked !== undefined;
  const [internal, setInternal] = React.useState(!!defaultChecked);
  const on = isControlled ? checked : internal;
  function toggle(e) {
    if (disabled) return;
    if (!isControlled) setInternal(!on);
    onChange && onChange(!on, e);
  }
  const track = on ? 'var(--colors-green-500)' : 'var(--colors-grey-300)';
  return /*#__PURE__*/React.createElement("label", {
    className: className,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 10,
      fontFamily: 'var(--font-sans)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.6 : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    role: "switch",
    "aria-checked": on,
    disabled: disabled,
    onClick: toggle,
    style: {
      width: 44,
      height: 24,
      borderRadius: 'var(--radius-full)',
      border: 'none',
      background: track,
      position: 'relative',
      cursor: disabled ? 'not-allowed' : 'pointer',
      transition: 'background-color .18s ease',
      padding: 0,
      flex: '0 0 auto'
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: 2,
      left: on ? 22 : 2,
      width: 20,
      height: 20,
      borderRadius: '50%',
      background: '#fff',
      boxShadow: 'var(--shadow-xs)',
      transition: 'left .18s ease'
    }
  })), label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 15,
      color: 'var(--text-primary)'
    }
  }, label));
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Underlined tab bar. Controlled (`value`/`onChange`) or uncontrolled.
 * `items`: [{ value, label, icon? }]
 */
function Tabs({
  items = [],
  value,
  defaultValue,
  onChange,
  style,
  className,
  ...rest
}) {
  const isControlled = value !== undefined;
  const [internal, setInternal] = React.useState(defaultValue ?? items[0]?.value);
  const active = isControlled ? value : internal;
  function select(v) {
    if (!isControlled) setInternal(v);
    onChange && onChange(v);
  }
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "tablist",
    className: className,
    style: {
      display: 'flex',
      gap: 4,
      borderBottom: '1px solid var(--border-subtle)',
      fontFamily: 'var(--font-sans)',
      ...style
    }
  }, rest), items.map(it => {
    const on = it.value === active;
    return /*#__PURE__*/React.createElement("button", {
      key: it.value,
      role: "tab",
      "aria-selected": on,
      onClick: () => select(it.value),
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: 8,
        padding: '12px 16px',
        border: 'none',
        background: 'transparent',
        cursor: 'pointer',
        fontFamily: 'var(--font-sans)',
        fontSize: 15,
        fontWeight: on ? 'var(--weight-semibold)' : 'var(--weight-medium)',
        color: on ? 'var(--colors-blue-800)' : 'var(--text-secondary)',
        borderBottom: `3px solid ${on ? 'var(--colors-blue-800)' : 'transparent'}`,
        marginBottom: -1,
        transition: 'color .15s ease, border-color .15s ease'
      }
    }, it.icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      name: it.icon,
      size: 18
    }), it.label);
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// ui_kits/portal/AppShell.jsx
try { (() => {
// AppShell — white top header (boxed logo + horizontal nav + profile) over a light canvas.
const {
  Logo,
  Icon,
  IconButton,
  Avatar,
  Button
} = window.SegurosUnimedDesignSystem_119381;
function AppShell({
  active,
  onNav,
  onLogout,
  children
}) {
  const D = window.PORTAL_DATA;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: '100%',
      background: 'var(--surface-page)',
      fontFamily: 'var(--font-sans)'
    }
  }, /*#__PURE__*/React.createElement("header", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 32,
      height: 72,
      padding: '0 32px',
      background: 'var(--surface-card)',
      borderBottom: '1px solid var(--border-subtle)',
      position: 'sticky',
      top: 0,
      zIndex: 10
    }
  }, /*#__PURE__*/React.createElement(Logo, {
    variant: "box",
    base: "../../assets/logos",
    height: 42
  }), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      gap: 4,
      marginLeft: 8
    }
  }, D.nav.map(n => {
    const on = n.id === active;
    return /*#__PURE__*/React.createElement("button", {
      key: n.id,
      onClick: () => onNav(n.id),
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: 8,
        padding: '8px 14px',
        border: 'none',
        background: on ? 'var(--colors-blue-0)' : 'transparent',
        borderRadius: 'var(--radius-sm)',
        cursor: 'pointer',
        fontFamily: 'var(--font-sans)',
        fontSize: 15,
        fontWeight: on ? 'var(--weight-semibold)' : 'var(--weight-medium)',
        color: on ? 'var(--colors-blue-800)' : 'var(--text-secondary)',
        transition: 'background-color .15s ease, color .15s ease'
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: n.icon,
      size: 18
    }), n.label);
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: 'auto',
      display: 'flex',
      alignItems: 'center',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    icon: "bell",
    "aria-label": "Notifica\xE7\xF5es",
    variant: "ghost"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      cursor: 'pointer'
    },
    onClick: onLogout,
    title: "Sair"
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: D.user.name,
    tone: "brand",
    size: "sm"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      fontWeight: 'var(--weight-semibold)',
      color: 'var(--text-primary)'
    }
  }, D.user.firstName), /*#__PURE__*/React.createElement(Icon, {
    name: "chevron-down",
    size: 16,
    color: "var(--text-tertiary)"
  })))), /*#__PURE__*/React.createElement("main", {
    style: {
      maxWidth: 1120,
      margin: '0 auto',
      padding: '32px'
    }
  }, children));
}
Object.assign(window, {
  AppShell
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/portal/AppShell.jsx", error: String((e && e.message) || e) }); }

// ui_kits/portal/DashboardScreen.jsx
try { (() => {
// DashboardScreen — greeting, summary stats, product cards, quick actions.
const {
  Card,
  Badge,
  Icon,
  Button,
  Avatar
} = window.SegurosUnimedDesignSystem_119381;
function StatPill({
  icon,
  label,
  value,
  accent
}) {
  return /*#__PURE__*/React.createElement(Card, {
    elevation: "sm",
    padding: 20,
    style: {
      flex: 1,
      display: 'flex',
      gap: 14,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 44,
      height: 44,
      borderRadius: 'var(--radius-sm)',
      background: 'var(--colors-blue-0)',
      color: accent || 'var(--su-navy)',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      flex: '0 0 auto'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: icon,
    size: 22
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: 'var(--text-secondary)'
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 20,
      fontWeight: 'var(--weight-semibold)',
      color: 'var(--text-primary)'
    }
  }, value)));
}
function ProductCard({
  p,
  onOpen
}) {
  return /*#__PURE__*/React.createElement(Card, {
    interactive: true,
    elevation: "sm",
    padding: 0,
    style: {
      overflow: 'hidden',
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 14,
      padding: '20px 20px 16px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 48,
      height: 48,
      borderRadius: 'var(--radius-md)',
      background: p.tint,
      color: p.accent,
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      flex: '0 0 auto'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: p.icon,
    size: 24
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 16,
      fontWeight: 'var(--weight-semibold)',
      color: 'var(--text-primary)'
    }
  }, p.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: 'var(--text-secondary)'
    }
  }, p.plan)), /*#__PURE__*/React.createElement(Badge, {
    tone: p.status === 'Ativo' ? 'success' : 'warning',
    dot: true
  }, p.status)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      borderTop: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      padding: '14px 20px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--text-tertiary)'
    }
  }, "Cobertura"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 'var(--weight-semibold)',
      color: 'var(--text-primary)'
    }
  }, p.coverage)), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      padding: '14px 20px',
      borderLeft: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--text-tertiary)'
    }
  }, "Mensal \xB7 vence ", p.due), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 'var(--weight-semibold)',
      color: 'var(--text-primary)'
    }
  }, p.monthly))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 20px 20px'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "sm",
    block: true,
    iconRight: "arrow-right",
    onClick: () => onOpen(p.id)
  }, "Ver detalhes")));
}
function DashboardScreen({
  onOpenProduct
}) {
  const D = window.PORTAL_DATA;
  const actions = [{
    icon: 'file-plus',
    label: 'Abrir sinistro'
  }, {
    icon: 'credit-card',
    label: 'Pagar parcela'
  }, {
    icon: 'download',
    label: 'Baixar apólice'
  }, {
    icon: 'headset',
    label: 'Falar com a gente'
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 28
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 500,
      fontSize: 34,
      color: 'var(--text-brand)',
      margin: 0
    }
  }, "Ol\xE1, ", D.user.firstName), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 16,
      color: 'var(--text-secondary)',
      marginTop: 6
    }
  }, "Aqui est\xE1 um resumo dos seus seguros. A gente cuida de quem voc\xEA ama.")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(StatPill, {
    icon: "shield-check",
    label: "Seguros ativos",
    value: "3 de 4"
  }), /*#__PURE__*/React.createElement(StatPill, {
    icon: "wallet",
    label: "Total mensal",
    value: "R$ 1.075,30",
    accent: "var(--su-green)"
  }), /*#__PURE__*/React.createElement(StatPill, {
    icon: "calendar-clock",
    label: "Pr\xF3ximo vencimento",
    value: "28/06",
    accent: "var(--su-orange)"
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: 20,
      fontWeight: 'var(--weight-semibold)',
      color: 'var(--text-primary)',
      margin: 0
    }
  }, "Meus seguros"), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm",
    iconLeft: "plus",
    style: {
      marginLeft: 'auto'
    }
  }, "Contratar novo")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(2, 1fr)',
      gap: 16
    }
  }, D.products.map(p => /*#__PURE__*/React.createElement(ProductCard, {
    key: p.id,
    p: p,
    onOpen: onOpenProduct
  })))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: 20,
      fontWeight: 'var(--weight-semibold)',
      color: 'var(--text-primary)',
      margin: '0 0 16px'
    }
  }, "A\xE7\xF5es r\xE1pidas"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4, 1fr)',
      gap: 16
    }
  }, actions.map(a => /*#__PURE__*/React.createElement(Card, {
    key: a.label,
    interactive: true,
    elevation: "xs",
    padding: 20,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10,
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 40,
      height: 40,
      borderRadius: 'var(--radius-sm)',
      background: 'var(--colors-blue-0)',
      color: 'var(--su-navy)',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: a.icon,
    size: 20
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      fontWeight: 'var(--weight-semibold)',
      color: 'var(--text-primary)'
    }
  }, a.label))))));
}
Object.assign(window, {
  DashboardScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/portal/DashboardScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/portal/LoginScreen.jsx
try { (() => {
// LoginScreen — split layout: navy brand panel + white sign-in form.
const {
  Logo,
  Input,
  Button,
  Icon,
  Checkbox
} = window.SegurosUnimedDesignSystem_119381;
function LoginScreen({
  onLogin
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      minHeight: '100vh',
      fontFamily: 'var(--font-sans)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: '1 1 46%',
      background: 'var(--su-navy)',
      color: '#fff',
      padding: '56px 56px',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'space-between',
      position: 'relative',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement(Logo, {
    variant: "white",
    base: "../../assets/logos",
    height: 40
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      zIndex: 1
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 500,
      fontSize: 44,
      lineHeight: 1.15,
      margin: 0
    }
  }, "Se \xE9 Unimed,", /*#__PURE__*/React.createElement("br", null), "\xE9 seguro."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 17,
      lineHeight: 1.6,
      color: 'rgba(255,255,255,.78)',
      marginTop: 20,
      maxWidth: 380
    }
  }, "Acesse a sua \xE1rea e acompanhe seus seguros, coberturas e pagamentos em um s\xF3 lugar.")), /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logos/pinheiro-white.svg",
    alt: "",
    style: {
      position: 'absolute',
      right: -40,
      bottom: -30,
      height: 360,
      opacity: 0.08,
      pointerEvents: 'none'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      color: 'rgba(255,255,255,.6)',
      position: 'relative',
      zIndex: 1
    }
  }, "\xA9 Seguros Unimed \xB7 Ouvidoria 0800 001 2424")), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: '1 1 54%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: 32,
      background: 'var(--surface-card)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      maxWidth: 380,
      display: 'flex',
      flexDirection: 'column',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 500,
      fontSize: 30,
      color: 'var(--text-brand)',
      margin: 0
    }
  }, "Entrar na sua conta"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 15,
      color: 'var(--text-secondary)',
      marginTop: 8
    }
  }, "Use o seu CPF e senha para acessar.")), /*#__PURE__*/React.createElement(Input, {
    label: "CPF",
    placeholder: "000.000.000-00",
    iconLeft: "user",
    defaultValue: "123.456.789-09"
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Senha",
    type: "password",
    placeholder: "Sua senha",
    iconLeft: "lock",
    defaultValue: "\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022",
    iconRight: "eye"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(Checkbox, {
    label: "Lembrar de mim",
    defaultChecked: true
  }), /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      fontSize: 14,
      fontWeight: 'var(--weight-semibold)',
      color: 'var(--text-brand)',
      textDecoration: 'none'
    }
  }, "Esqueci a senha")), /*#__PURE__*/React.createElement(Button, {
    block: true,
    onClick: onLogin
  }, "Entrar"), /*#__PURE__*/React.createElement("p", {
    style: {
      textAlign: 'center',
      fontSize: 14,
      color: 'var(--text-secondary)',
      margin: 0
    }
  }, "Ainda n\xE3o \xE9 cliente? ", /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      color: 'var(--text-brand)',
      fontWeight: 'var(--weight-semibold)',
      textDecoration: 'none'
    }
  }, "Conhe\xE7a nossos seguros")))));
}
Object.assign(window, {
  LoginScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/portal/LoginScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/portal/ProductDetailScreen.jsx
try { (() => {
// ProductDetailScreen — product header, tabs, coverages / payments.
const {
  Card,
  Badge,
  Icon,
  Button,
  Tabs,
  Alert
} = window.SegurosUnimedDesignSystem_119381;
function CoverageRow({
  c
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 14,
      padding: '16px 0',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 40,
      height: 40,
      borderRadius: 'var(--radius-sm)',
      background: 'var(--colors-green-0)',
      color: 'var(--su-green)',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      flex: '0 0 auto'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: c.icon,
    size: 20
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      fontSize: 15,
      fontWeight: 'var(--weight-medium)',
      color: 'var(--text-primary)'
    }
  }, c.name), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      fontWeight: 'var(--weight-semibold)',
      color: 'var(--text-secondary)'
    }
  }, c.value));
}
function PaymentRow({
  p
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 14,
      padding: '14px 0',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 36,
      height: 36,
      borderRadius: 'var(--radius-full)',
      background: 'var(--colors-green-0)',
      color: 'var(--su-green)',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      flex: '0 0 auto'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "check",
    size: 18,
    strokeWidth: 2.5
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 15,
      fontWeight: 'var(--weight-medium)',
      color: 'var(--text-primary)'
    }
  }, p.desc), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: 'var(--text-tertiary)'
    }
  }, p.date)), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 15,
      fontWeight: 'var(--weight-semibold)',
      color: 'var(--text-primary)'
    }
  }, p.value), /*#__PURE__*/React.createElement(Badge, {
    tone: "success"
  }, p.status));
}
function ProductDetailScreen({
  productId,
  onBack
}) {
  const D = window.PORTAL_DATA;
  const p = D.products.find(x => x.id === productId) || D.products[0];
  const [tab, setTab] = React.useState('coberturas');
  const coverages = D.coverages[p.id] || D.coverages.vida;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: onBack,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      border: 'none',
      background: 'transparent',
      cursor: 'pointer',
      color: 'var(--text-secondary)',
      fontFamily: 'var(--font-sans)',
      fontSize: 14,
      fontWeight: 'var(--weight-semibold)',
      padding: 0,
      alignSelf: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "arrow-left",
    size: 18
  }), " Voltar para meus seguros"), /*#__PURE__*/React.createElement(Card, {
    elevation: "sm",
    padding: 28,
    style: {
      display: 'flex',
      gap: 20,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 64,
      height: 64,
      borderRadius: 'var(--radius-md)',
      background: p.tint,
      color: p.accent,
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      flex: '0 0 auto'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: p.icon,
    size: 32
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 500,
      fontSize: 28,
      color: 'var(--text-brand)',
      margin: 0
    }
  }, p.name), /*#__PURE__*/React.createElement(Badge, {
    tone: p.status === 'Ativo' ? 'success' : 'warning',
    dot: true
  }, p.status)), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 15,
      color: 'var(--text-secondary)',
      margin: '6px 0 0'
    }
  }, p.plan, " \xB7 Ap\xF3lice ", p.policy)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    iconLeft: "download",
    size: "md"
  }, "Ap\xF3lice"), /*#__PURE__*/React.createElement(Button, {
    iconLeft: "file-plus",
    size: "md"
  }, "Abrir sinistro"))), p.status === 'Renovar' && /*#__PURE__*/React.createElement(Alert, {
    tone: "warning",
    title: "Renova\xE7\xE3o dispon\xEDvel"
  }, "Seu seguro vence em ", p.due, ". Renove agora para manter a prote\xE7\xE3o sem interrup\xE7\xE3o."), /*#__PURE__*/React.createElement(Tabs, {
    value: tab,
    onChange: setTab,
    items: [{
      value: 'coberturas',
      label: 'Coberturas',
      icon: 'list-checks'
    }, {
      value: 'pagamentos',
      label: 'Pagamentos',
      icon: 'credit-card'
    }, {
      value: 'documentos',
      label: 'Documentos',
      icon: 'file-text'
    }]
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 320px',
      gap: 20,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    elevation: "sm",
    padding: 24
  }, tab === 'coberturas' && /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: 17,
      fontWeight: 'var(--weight-semibold)',
      color: 'var(--text-primary)',
      margin: '0 0 8px'
    }
  }, "O que est\xE1 coberto"), coverages.map(c => /*#__PURE__*/React.createElement(CoverageRow, {
    key: c.name,
    c: c
  }))), tab === 'pagamentos' && /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: 17,
      fontWeight: 'var(--weight-semibold)',
      color: 'var(--text-primary)',
      margin: '0 0 8px'
    }
  }, "Hist\xF3rico de pagamentos"), D.payments.map(pay => /*#__PURE__*/React.createElement(PaymentRow, {
    key: pay.date,
    p: pay
  }))), tab === 'documentos' && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: 17,
      fontWeight: 'var(--weight-semibold)',
      color: 'var(--text-primary)',
      margin: '0 0 4px'
    }
  }, "Documentos da ap\xF3lice"), ['Apólice completa.pdf', 'Condições gerais.pdf', 'Manual do segurado.pdf'].map(doc => /*#__PURE__*/React.createElement("div", {
    key: doc,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      padding: '14px 16px',
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-sm)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "file-text",
    size: 20,
    color: "var(--su-navy)"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      fontSize: 14,
      fontWeight: 'var(--weight-medium)',
      color: 'var(--text-primary)'
    }
  }, doc), /*#__PURE__*/React.createElement(Icon, {
    name: "download",
    size: 18,
    color: "var(--text-tertiary)"
  }))))), /*#__PURE__*/React.createElement(Card, {
    elevation: "sm",
    padding: 24,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: 16,
      fontWeight: 'var(--weight-semibold)',
      color: 'var(--text-primary)',
      margin: 0
    }
  }, "Resumo"), [['Cobertura', p.coverage], ['Mensalidade', p.monthly], ['Vencimento', p.due], ['Apólice', p.policy]].map(([k, v]) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      fontSize: 14
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-secondary)'
    }
  }, k), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 'var(--weight-semibold)',
      color: 'var(--text-primary)'
    }
  }, v))), /*#__PURE__*/React.createElement(Button, {
    block: true,
    iconLeft: "credit-card"
  }, "Pagar parcela"))));
}
Object.assign(window, {
  ProductDetailScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/portal/ProductDetailScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/portal/data.js
try { (() => {
// Mock data for the Seguros Unimed customer portal (Área do Cliente).
window.PORTAL_DATA = {
  user: {
    name: 'Ana Carolina Lima',
    firstName: 'Ana',
    cpf: '123.•••.•••-09'
  },
  products: [{
    id: 'saude',
    name: 'Seguro Saúde',
    line: 'Saúde',
    icon: 'heart-pulse',
    plan: 'Plano Unimed Pleno',
    policy: '0042-118-2231',
    status: 'Ativo',
    coverage: 'R$ 500.000,00',
    monthly: 'R$ 842,90',
    due: '10/07/2026',
    accent: 'var(--su-green)',
    tint: 'var(--colors-green-0)'
  }, {
    id: 'odonto',
    name: 'Seguro Odontológico',
    line: 'Odonto',
    icon: 'smile',
    plan: 'Odonto Mais',
    policy: '0091-553-8870',
    status: 'Ativo',
    coverage: 'Rede credenciada',
    monthly: 'R$ 64,90',
    due: '10/07/2026',
    accent: 'var(--su-sky)',
    tint: 'var(--colors-cyan-0)'
  }, {
    id: 'vida',
    name: 'Seguro de Vida',
    line: 'Vida',
    icon: 'shield',
    plan: 'Vida Protegida',
    policy: '0042-117-0098',
    status: 'Ativo',
    coverage: 'R$ 250.000,00',
    monthly: 'R$ 119,00',
    due: '15/07/2026',
    accent: 'var(--su-navy)',
    tint: 'var(--colors-blue-0)'
  }, {
    id: 'residencial',
    name: 'Seguro Residencial',
    line: 'Residencial',
    icon: 'home',
    plan: 'Casa Segura',
    policy: '0077-220-4512',
    status: 'Renovar',
    coverage: 'R$ 180.000,00',
    monthly: 'R$ 48,50',
    due: '28/06/2026',
    accent: 'var(--su-orange)',
    tint: 'var(--colors-orange-0)'
  }],
  nav: [{
    id: 'inicio',
    label: 'Início',
    icon: 'house'
  }, {
    id: 'seguros',
    label: 'Meus seguros',
    icon: 'shield-check'
  }, {
    id: 'coberturas',
    label: 'Coberturas',
    icon: 'list-checks'
  }, {
    id: 'ajuda',
    label: 'Ajuda',
    icon: 'circle-help'
  }],
  coverages: {
    saude: [{
      name: 'Internação hospitalar',
      value: 'Cobertura total',
      icon: 'bed'
    }, {
      name: 'Consultas e exames',
      value: 'Ilimitado na rede',
      icon: 'stethoscope'
    }, {
      name: 'Pronto-socorro 24h',
      value: 'Nacional',
      icon: 'ambulance'
    }, {
      name: 'Teleconsulta',
      value: 'Incluída',
      icon: 'video'
    }],
    vida: [{
      name: 'Morte por qualquer causa',
      value: 'R$ 250.000,00',
      icon: 'shield'
    }, {
      name: 'Invalidez por acidente',
      value: 'R$ 250.000,00',
      icon: 'heart-handshake'
    }, {
      name: 'Assistência funeral',
      value: 'Incluída',
      icon: 'flower'
    }, {
      name: 'Diária de internação',
      value: 'R$ 150,00/dia',
      icon: 'bed'
    }]
  },
  payments: [{
    date: '10/06/2026',
    desc: 'Parcela 06/12',
    value: 'R$ 842,90',
    status: 'Pago'
  }, {
    date: '10/05/2026',
    desc: 'Parcela 05/12',
    value: 'R$ 842,90',
    status: 'Pago'
  }, {
    date: '10/04/2026',
    desc: 'Parcela 04/12',
    value: 'R$ 842,90',
    status: 'Pago'
  }]
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/portal/data.js", error: String((e && e.message) || e) }); }

__ds_ns.Button = __ds_scope.Button;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.Logo = __ds_scope.Logo;

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.Alert = __ds_scope.Alert;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Radio = __ds_scope.Radio;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Tabs = __ds_scope.Tabs;

})();
