# Seguros Unimed — Design System

Um design system orientado a código para a **Seguros Unimed**, a seguradora do Sistema Cooperativo Unimed. Reúne as fundações da marca (cor, tipografia, espaçamento, lockups do logo), primitivos de UI em React reutilizáveis, UI kits de produtos em tela cheia e templates de slides — para que qualquer time produza interfaces e materiais dentro da marca, seja em produção ou protótipos descartáveis.

> **Tagline:** *Se é Unimed, é seguro.*

## Sobre a empresa

A Seguros Unimed é uma seguradora brasileira com portfólio nas linhas **Saúde, Odonto, Vida, Previdência, Residencial, Patrimonial e Responsabilidade Civil**. Seus principais pontos de contato são apresentações institucionais, comunicações impressas e digitais, e campanhas por linha de produto. O tom é **caloroso, cooperativo e protetor** — uma parceira que cuida das pessoas e da cooperativa.

## Fontes

- **Figma:** *"DSU Core Web.fig"* — a biblioteca de componentes "Core Web" da Seguros Unimed (Cover, About, Content, Actions, Containers, Navigation, Inputs, Status, Feedback). Montada como somente-leitura durante a autoria; 628 componentes locais, ~717 variáveis de design. Os tokens de cor, espaçamento, raio e tipografia aqui foram extraídos da coleção de variáveis desse arquivo e dos specimens Texts/Brand.
- **Notas de marca** fornecidas com o briefing do projeto (construção do logo, regras de paleta, tipografia, tom, área de segurança e usos proibidos).
- **Manual de Linguagem da Marca Seguros Unimed v1 (Nov 2022)** — fonte autoritativa para paleta, hierarquia tipográfica, tom de voz e regras de composição. Texto completo em `guidelines/_brand-manual-text.txt`.

Os ativos que não puderam ser resolvidos a partir do arquivo (o conjunto de ícones do produto) estão substituídos e sinalizados abaixo — ver *Ressalvas*. As tipografias proprietárias **Unimed Sans** e **Unimed Slab** agora são auto-hospedadas a partir dos arquivos licenciados fornecidos pela marca.

## Identidade da marca em resumo

- **Sistema do logo — o "box de assinatura":** um box de assinatura com **três cantos arredondados e um canto reto (inferior direito)**, interior branco. Existem quatro variantes: com/sem o símbolo do *Pinheiro*, com/sem o box. **O box é obrigatório sobre fundos coloridos e fotográficos**; a versão sem box é restrita a fundos sólidos de alto contraste.
- **A tipografia do logo é fixa:** "SEGUROS" em bold condensado caixa alta (azul marinho) + "Unimed" em bold arredondado (verde). Nunca substituir ou modificar — ela vive dentro dos SVGs do logo, nunca como texto editável.
- **Cores:** o **Manual de Linguagem (p.94) define quatro cores primárias** — verde institucional `#00995D` (348C), azul `#009EDB` (299C), azul marinho `#002D74` (288C) e laranja `#F47920` (1585C); todas usáveis em tons de 20/40/60/80/100%. Uma **paleta de comunicação** separada, com seis tons (coral, rosa, areia, âmbar, verde-salva, azul-céu), é para campanhas, codificação de categorias e ilustração — nunca como cores de estado de UI. **Cores fora da paleta são proibidas** (exceto os meses de conscientização em saúde aprovados, ver documento de correções).
- **Área de segurança** definida pela altura do caractere "U"; **tamanhos mínimos**: 55–70px no digital / 20–25mm em impressos, conforme a variante. O *Pinheiro* avulso é apenas para casos especiais e nunca ao lado de um logo que já contém o símbolo.
- **Proibido:** rotação, distorção, redução de opacidade, inversão de cores, alteração dos cantos arredondados, tipografia fora da marca, uso sem box sobre fotos/fundos coloridos, e qualquer efeito gráfico sobre o logo.

---

## FUNDAMENTOS DE CONTEÚDO

Como a Seguros Unimed escreve. (O idioma principal é o **Português Brasileiro**.) Estas regras seguem o *Manual de Linguagem da Marca* oficial (v1, Nov 2022).

**Tom de voz — os três pilares.** Toda peça de texto deve ser:

1. **Próximo** *(acolhedor)* — comunicação empática e não violenta; coloque-se no lugar de quem lê. Valorize as pessoas, a cultura regional e os depoimentos reais; humanize o conteúdo. Convide ("Vamos juntos?").
2. **Didático** — oriente e informe, passo a passo. Claro, direto, objetivo. Pergunte e responda de forma simples. **Evite estrangeirismos**; explique termos técnicos com clareza. **Frases curtas em ordem direta.** Conte histórias com começo, meio e fim.
3. **Propositivo** — fale com a autoridade da maior cooperativa médica do mundo. Baseie afirmações em **fatos e dados**; faça recomendações e ofereça dicas a partir de conhecimento médico e fontes oficiais de saúde, para melhorar a qualidade de vida das pessoas.

**Essência da marca (contexto).** Propósito: *"AQUI TEM UNIMED"* — promover saúde e qualidade de vida por meio do cooperativismo médico. Crença: *"A vida é o bem maior do ser humano."* Atributos desejados: *vocacionada para o cuidado · autoridade em saúde · parte da comunidade · descomplicada · segurança e confiança · sustentabilidade.* Valores: integridade, respeito, solidariedade, espírito cooperativista.

**Mecânica**
- **Pessoa e tratamento:** fale **com** o cliente usando **"você"**; a marca é "nós" / "a gente cuida". Evite o distante "o cliente deve…"; prefira "você pode…".
- **Caixa:** sentence case para títulos, labels e botões ("Contratar seguro", "Meus produtos"). CAIXA ALTA apenas no wordmark travado do logo e em labels de Chapéu/eyebrow. Nunca use title case em strings de UI em português.
- **CTAs:** curtos, com verbo à frente, no imperativo — "Contratar", "Simular agora", "Ver detalhes", "Falar com a gente". Encerre com um **único** CTA claro.
- **Números e valores:** formato brasileiro — `R$ 1.250,00`, datas `dd/mm/aaaa`, separador decimal vírgula, "12,5%". Cite fontes de dados (ex.: "segundo a OMS…").
- **Emoji:** não faz parte da voz — evite na UI de produto e em comunicações formais. Ícones e infográficos cumprem esse papel.
- **Taglines:** *"Se é Unimed, é seguro."* é a assinatura da Seguros Unimed, restrita às versões do logo **acompanhadas do módulo do Pinheiro**. *"Aqui tem Unimed."* é a linha de propósito do sistema.
- **Exemplos:** "Sabia que o seu seguro pode proteger toda a família?" (próximo + didático) · "Simule em poucos minutos, sem complicação." (descomplicada) · "A gente cuida de quem você ama." (próximo)

---

## FUNDAÇÕES VISUAIS

- **Vibe de cor:** institucional e confiável. As **quatro primárias** são verde `#00995D`, azul `#009EDB`, azul marinho `#002D74` e laranja `#F47920` (todas em tons de 20–100%). Os neutros são cinzas azulados frios (`#e6eaf2`, `#f8f9fc`). Uma **paleta de comunicação** separada, de seis tons (coral, rosa, areia, âmbar, verde-salva, azul-céu), cuida de campanhas e ilustração. A camada **semântica** de UI (perigo/aviso/informação) é um sistema distinto — atenção: o roxo `#7D4BD2` **não** está no Manual e precisa de aprovação da marca. Cores fora da paleta são proibidas (com exceção documentada para meses de conscientização em saúde). Os fundos são predominantemente **brancos / cinza-azulado bem claro** — limpos, arejados, nunca gradientes pesados.
- **Tipografia:** **Archivo** (Medium 500) para títulos de display — geométrica, confiante, em azul marinho. **Unimed Sans** (auto-hospedada; Light 300 · Book 400 · Regular 500 · SemiBold 600 · Bold 700 · ExtraBold 800, mais um corte BoldCondensed para grandes estatísticas, com itálicos) para todo o resto — corpo, labels, UI. **Unimed Slab/Serif** para texto editorial longo; **Unimed Brush** apenas para chamadas emocionais curtas. Os labels de **Chapéu/eyebrow** são Unimed Sans SemiBold, CAIXA ALTA, com tracking, verde sobre fundos claros. Títulos de display são compactos (`line-height 1.24`); o corpo é `1.5`. Grandes headlines editoriais (até 64px) são uma assinatura.
- **Espaçamento e grid:** passo de 8pt (`4 · 8 · 12 · 16 · 20 · 24 · 32 · 40 · 48 · 56 · 64 · 80`) sobre um **grid modular da marca de 20×20pt**; gutter de página 24, margem 72. Espaço em branco generoso; o conteúdo respira.
- **Raio de canto:** suave, porém contido — `8px` em botões/inputs/chips, `16px` em cards, `24px` em modais/grandes superfícies. O motif principal da marca é o **box de assinatura** (`12px 12px 0 12px` — três arredondados, um reto) usado em lockups do logo e como frame decorativo.
- **Cards:** superfície branca, raio `16px`, borda hairline `#e6eaf2` e/ou uma sombra suave de baixo contraste (`0 2px 8px rgba(24,25,26,.08)`). Sem acentos de borda lateral colorida.
- **Bordas:** hairlines de 1px em `#e6eaf2`/`#d3d7df`; estados de ênfase/ativo usam azul marinho em 1px ou um anel de foco de 3px (`rgba(33,107,219,.35)`).
- **Sombras:** suaves, difusas, baixa opacidade (6–12% de quase-preto). A elevação é gentil — este é um sistema calmo, com tendência a flat, não um material design pesado.
- **Botões:** primário = navy sólido, raio `8px`, label branco, 64px de altura (LG); hover escurece para `#001e4c`. Secundário = branco com hairline `#e6eaf2` + label navy; hover deixa a borda navy. Sucesso = verde. Desabilitado = fundo `#e6eaf2` + label cinza. Loading mostra um spinner em anel.
- **Movimento:** sutil e funcional — fades curtos e transições de 150–200ms ease em hover/press; sem bounces ou loops decorativos chamativos. Estados de press escurecem o preenchimento (sem grandes mudanças de escala).
- **Uso do branco:** um recurso gráfico fundamental — áreas generosas de respiro reforçam a identidade e emolduram boxes de logo/texto. Proporção recomendada em layouts editoriais: **imagem 50–80%, branco 20–50%** da área.
- **Imagens:** fotografia calorosa, humana, otimista — pessoas reais, famílias, cuidado, expressões (sorrisos, olhar atento), texturas (pele, ambiente) e cenários **locais/regionais**; sobre fotos, o logo sempre usa o box. As **ilustrações** trazem traços gestuais e textura para autenticidade; ícones e infográficos mantêm informações complexas simples ("poucos traços, apenas o essencial").
- **Motif do Box Unimed:** derivado da silhueta do logo, o box de assinatura arredondado é um dispositivo de identidade chave usado para emoldurar texto e imagem, não apenas o logo.
- **Regras de layout:** telas brancas/cinza-claras, ritmo modular claro, navegação superior fixa em navy ou branco, larguras máximas de conteúdo com margens confortáveis.

---

## ICONOGRAFIA

O Figma entrega os ícones via placeholders de instance-swap, então o conjunto original de ícones Unimed não é extraível do arquivo. O conjunto se lê como **ícones de linha de peso único e limpos** em **16px e 24px**, monocromáticos (herdando a cor de texto/marca), com junções arredondadas amigáveis — coerentes com a marca calorosa.

**Substituto:** [**Lucide**](https://lucide.dev) (carregado via CDN) — ícones de linha com cantos arredondados, traço de 2px, que combinam de perto com o estilo de traço da marca. Uso:
- Tamanhos: `16px` (inline / UI densa) e `20–24px` (padrão). Traço ~`1,75–2`.
- Cor: herda `currentColor` — tipicamente `--text-secondary` para neutro, `--su-navy`/`--su-green` para ênfase.
- Sem emoji como ícone; sem ícones multicoloridos na UI de produto.

Sinalização: substituir o Lucide pelo conjunto de ícones Unimed licenciado quando disponível — ver *Ressalvas*.

---

## Índice / Manifesto

**Raiz**
- `styles.css` — entrada global de CSS (somente imports). Os consumidores vinculam este arquivo.
- `readme.md` — este guia.
- `SKILL.md` — wrapper de Agent Skill.

**Tokens** (`tokens/`)
- `colors.css` · `typography.css` · `spacing.css` · `fonts.css`

**Ativos** (`assets/`)
- `logos/` — `seguros-unimed-box.svg` (primário, com box), `seguros-unimed-symbol.svg` (sem box), `seguros-unimed-white.svg` (inverso), `pinheiro.svg` (currentColor), `pinheiro-navy/green/white.svg`.

**Fundações** (`guidelines/`) — specimen cards para a aba Design System (Type, Colors, Spacing, Brand).

**Componentes** (`components/`) — primitivos React reutilizáveis, cada um com `.jsx` + `.d.ts` + um card:
- `brand/` — **Logo** (lockups aprovados), **Icon** (wrapper do Lucide)
- `actions/` — **Button**, **IconButton**
- `forms/` — **Input**, **Select**, **Checkbox**, **Radio**, **Switch**
- `data-display/` — **Card**, **Badge**, **Tag**, **Avatar**
- `feedback/` — **Alert**
- `navigation/` — **Tabs**

**UI kits** (`ui_kits/`)
- `portal/` — *Área do Cliente*: portal do cliente interativo login → painel → detalhe da apólice (`index.html`).

**Slides** (`slides/`) — templates de apresentação institucional (1280×720): `title`, `section`, `content`, `stats`, `closing`.

**Referência**
- `guidelines/_brand-manual-text.txt` — texto completo extraído do *Manual de Linguagem da Marca* oficial (v1, Nov 2022), mantido para consultas mais profundas.

---

## Ressalvas
- **Unimed Sans** e **Unimed Slab** (proprietárias) são **auto-hospedadas** a partir dos arquivos licenciados em `fonts/` (`tokens/fonts.css`). Mapa de pesos: Light 300 · Book 400 · Regular 500 · SemiBold 600 · Bold 700 · ExtraBold 800.
- **Unimed Serif** e **Unimed Brush** são subfamílias documentadas no Manual, mas ainda **sem arquivos**. Os tokens `--font-serif`/`--font-brush` serão adicionados junto com seus `@font-face` assim que as fontes forem enviadas.
- **Archivo** (display) carrega via CDN do Google Fonts — a marca não forneceu arquivos para ela; migrar para auto-hospedado quando/se forem fornecidos.
- **Conjunto de ícones** substituído por **Lucide** (CDN). Substituir pelo conjunto de ícones Unimed licenciado quando disponível.
- Os valores de cor/espaçamento/tipografia foram extraídos da coleção de variáveis do Figma e da paleta do *Manual de Linguagem* oficial.
